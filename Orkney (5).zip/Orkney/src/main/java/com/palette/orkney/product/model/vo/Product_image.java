package com.palette.orkney.product.model.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product_image {
	
	private String product_pic;
	private String product_no;
	private String product_color;

}
